<?php
$topics = $result["data"]['topics'];
$posts = $result['data']['posts'];
?>
<h2>Detail du post </h2>
<?php
foreach($topics as $topic){ 
   ?>
   <?=$post->getContent()?>
    <?php
}
?>
